package com.shopping.enums;


public interface CodeEnum {
    Integer getCode();

}
