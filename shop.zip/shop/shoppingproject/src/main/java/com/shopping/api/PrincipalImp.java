package com.shopping.api;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

@Configuration
public class PrincipalImp {
	
	
	

}
